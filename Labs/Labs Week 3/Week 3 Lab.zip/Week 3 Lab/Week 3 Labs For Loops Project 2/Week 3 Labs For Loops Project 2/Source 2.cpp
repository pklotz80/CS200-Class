#include <iostream>
using namespace std;

int main()
{
	for (int i = 10; i <=100; i += 5)
	{
		cout << i << "\t";
	}

	while (true) {}
	return 0;
}