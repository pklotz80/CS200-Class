#include <iostream>
using namespace std;

int main()
{
	for (int i = 0; i < 20; i++)
	{
		cout << i << "\t";
	}

	while (true) {}
	return 0;
}