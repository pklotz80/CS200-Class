#include <iostream>
using namespace std;

int main()
{
	for (int i = 50; i > 0; i -= 2)
	{
		cout << i << "\t";
	}

	while (true) {}
	return 0;
}