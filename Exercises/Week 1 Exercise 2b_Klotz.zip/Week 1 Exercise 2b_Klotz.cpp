//Assignment: Week 1 Exercise 2b
//Student Name: Paula Klotz
//Date: 01/26/2017
//Program Description:  When I only show cout << likesPizza, the number 1 is displayed.  When my if statement shows
//(likesPizza = true), the message that is displayed reads "Likes Pizza."  When my if statement shows (likesPizza = false), 
//the message that is displayed reads "Doesn't like pizza."

#include <iostream>
#include <string>
using namespace std;

int main()

{
	bool likesPizza;

	if (likesPizza = true)
	{
		cout << "Likes pizza." << endl;
	}

	else
	{
		cout << "Doesn't like pizza." << endl;
	}

	while (true) {}
	return 0;
}